package com.infinite.microservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyExchangeService extends JpaRepository<ExchangeValue,Long>{
	ExchangeValue findByFromAndTo(String from,String to);

}
